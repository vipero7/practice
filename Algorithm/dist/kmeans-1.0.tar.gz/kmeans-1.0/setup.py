from setuptools import setup

setup(
    name='kmeans',
    version='1.0',
    description='K means clustering algorithm',
    author='vipero7',
    author_email='pankajbhattarai100@gmail.com',
    py_modules=['kmeans'],
)
